CREATE PROCEDURE person_generate 
	( Str_in IN number)
IS

BEGIN
	FOR i IN 1.. Str_in LOOP
		INSERT ALL 
    INTO person (Person_id, Lname, Fname, Adress, Pole, Email)
    VALUES (Person_sc.NEXTVAL, DBMS_RANDOM.STRING ('a', DBMS_RANDOM.VALUE (3,15)), 
    DBMS_RANDOM.STRING ('a', DBMS_RANDOM.VALUE (5,15)), 
    DBMS_RANDOM.STRING ('a', DBMS_RANDOM.VALUE (7,20)), 
    DBMS_RANDOM.VALUE (1,2), 
    DBMS_RANDOM.STRING ('x', DBMS_RANDOM.VALUE (3,8)) || '@te.net.ua ')
    INTO phones (id, ph_number, person_id)
    VALUES (Phones_sc.NEXTVAL, '+38'||to_char(round(DBMS_RANDOM.VALUE(10000000000,1000000000),0)), Person_sc.currval )
    SELECT * FROM dual;
	END LOOP;	
END;
/
